
Messages = {}
Messages.danger = [];
Messages.success = [];
Messages.clear = function () { Messages.danger = []; Messages.success = []; }
